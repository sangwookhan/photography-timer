# PTIMER-235 iteration 05 captures

Implementation commits (PR 74): d62f3639 Mini Timer 1x, 202d73e1 Timers+Details (chip/value alignment fixed in Details), 7ca91f92 Main (chips, result card, labels). Spec baseline PR 73 revision 7dd1376b620b3bf001100f20d8cfac92edae3c0d.
Before = origin/main 8b3b6cdb. After = 7ca91f92. Same emulator (1080x2424, density 480, Roboto), same state: Fomapan 100 Classic, ND 10 stops, target shutter 1m, one running timer 6m 35s unless named no-timer.

## Root causes (source + capture)
1. Model chips (Main and Details): a FilterChip is 32 dp tall when its label is one line; the sibling with a two-line label grows, nothing equalised them. Fix: the chip Row uses height(IntrinsicSize.Min) and each chip fillMaxHeight().
2. Result card squeeze (Main with a timer peek): the page needs more height than the room above the peek, so the page Column gave its last children what was left; Reciprocity and Corrected Exposure were compressed, Corrected was hidden or pressed to the card edge. Fix: the page Column scrolls only when taller than that room (verticalScroll) and lays children out at natural size.
3. Dead band: while the peek shows, the Main Scaffold still reserved the navigation-bar inset that the peek covers (72 px between page dots and peek). Fix: reserve nothing then (reserveNavigationBarInset=false while a timer exists).
4. Details Adjusted/Corrected values: each column was a plain Column, so a wrapping label pushed only its own value down. Fix: Row height IntrinsicSize.Min, each column SpaceBetween (label top, value bottom).
5. Label containment: BoundedScaledLabel no longer lets text overflow its slot (unbounded vertical wrap removed); slot = the 48 dp touch row the parent already has; the page label stays 1x.
6. "395s" small: it is the secondary seconds value (labelSmall by design, same for Adjusted); the primary value "6m 35s" is the same size as 34.133s. It looked small because the primary value was under the peek.

## Files
before/ after/: main, timers, details at 1.0, 1.3, 2.0 (after also main 1.2); main-no-timer at 1.0/2.0 before and 1.0/1.2/2.0 after.
extra/: main_1.0_timer_scrolled-to-corrected (scroll reveals the complete Corrected row), wheel drag test (ND 10 -> 12, page did not scroll), details_* cap-removed-test-build (test build with the Details 1x cap lifted, to prove the value alignment when both labels wrap; not shipped).
measurements/: uiautomator bounds per file, summary_geometry.txt.

## Numbered PASS/FAIL for the nine items (after, emulator, matched state)
1. Main model chips equal height/alignment: PASS (after/main_scale-1.0.png: both chips 387..505 px at the displayed scale; before: left chip shorter).
2. Reciprocity row vertical placement/spacing: PASS at rest and when scrolled (extra/main_1.0_timer_scrolled...): Adjusted -> Reciprocity -> Corrected spacing is the designed one (48 dp rows, divider padding).
3. Corrected Exposure value legibility/alignment: PASS when scrolled into view and with no timer: 6m 35s same size and right edge as 34.133s; 395s is the secondary value by design.
4. Corrected row vs Mini Timer peek: PARTIAL. Predates this PR (baseline 8b3b6cdb hides the whole row and it cannot be reached; first seen with the Filter Stack work). Now the row is reachable and operable by scrolling the page (about 94 px) and the card is no longer squeezed, but at rest with a timer the row is still only partly visible. It needs about 140 px that the screen does not have without changing wheel/card sizes. Product decision needed (scroll is the fix applied).
5. Details chips equal height: PASS (after/details_scale-1.0.png and extra cap-removed 2.0).
6. Details Adjusted/Corrected value alignment when labels wrap: PASS on the cap-removed test build at 2.0 (labels 750..942, values 942..1086 for both). In the shipped build Details is held at 1x so labels do not wrap.
7. BoundedScaledLabel containment: PASS (text inside the 48 dp slot; no unbounded overflow); page label stays 1x.
8. Other component sizes/positions/alignment across scales: PASS 0 px at 1.3 and 2.0 for Main, Timers, Details (summary_geometry.txt); Mini Timer identical to 1.0.
9. SHELL-022 label growth retained: PASS up to 1.2 inside bounded slots (after/main-no-timer_scale-1.2.png); at 1.3 Corrected Exposure would ellipsize, hence the cap.

## Remaining defects
- Item 4 as above. Mini Timer film name ellipsized and Timers title ellipsized for long names (baseline). Below 0.85 bounds shift as in the baseline. Gate A (1.0) and Gate B (1.3/max) were inspected on the PNGs, not only measured.
