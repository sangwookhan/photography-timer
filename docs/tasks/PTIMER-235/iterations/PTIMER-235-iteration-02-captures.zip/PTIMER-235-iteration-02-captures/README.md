# PTIMER-235 iteration 02 captures

Implementation commit: d24d6de4 (PR 74 head; d62f3639 Mini Timer, d24d6de4 Timers + Details). Spec baseline: PR 73 revision 7dd1376b620b3bf001100f20d8cfac92edae3c0d.
Before = origin/main 8b3b6cdb (0.9.0). After = d24d6de4. Same emulator (1080x2424, density 480, en-US), same state: Fomapan 100 Classic, ND 10 stops, target shutter 1m, one running timer 6m 35s.

## Files (screen, scale)
| Screen | before | after |
| --- | --- | --- |
| Main + Mini Timer | before/main_scale-{0.85,1.0,1.3,2.0}.png | after/main_scale-{0.85,1.0,1.3,2.0}.png |
| Timers | before/timers_scale-*.png | after/timers_scale-*.png |
| Details | before/details_scale-*.png | after/details_scale-*.png |

measurements/ holds uiautomator bounds (text|bounds|clickable) per screen and scale; summary.txt gives the max shift of clickable component bounds relative to scale 1.0.

## Findings (measured)
- Before: Main shift 0 px at 1.3 and 2.0 (surface pinned at 1x); Timers shift 570 px at 1.3/2.0 (Cancel wraps, sheet grows); Details shift 258 px at 1.3/2.0 (title/chips/rows wrap).
- Experiment (temporary build, not in the PR): enlarging Main labels moves the Reciprocity row and Corrected start button by 2 px at 1.05, 11 px at 1.15; Timers sheet moves 26 px at 1.05; Details 9 px at 1.05. No enlargement is geometry-invariant, so none is shipped.
- After: 0 px shift at 1.3 and 2.0 for Main, Timers, Details (identical component bounds to 1.0).
- Mini Timer at 2.0 is identical to 1.0 (countdown readable).

## Remaining visual defects
- At 0.85 (below default) bounds shift: Main 48 px, Timers 81 px, Details 49 px; identical in before and after (not changed by this PR).
- Mini Timer film name ellipsized ("Fomapan 10…") at 1.0 and above, as before.
- Timers card title ellipsized at 1.0 for long film names, as before.
- Corrected Exposure hidden by the timer peek bar on Main at every scale (separate known issue).
- The result: system font size above 1.0 no longer enlarges text on Main, Mini Timer, Timers or Details (Timers/Details used to enlarge to 1.3). SHELL-022 growth ("labels grow where the layout has room") is not delivered because no label growth was geometry-invariant.
