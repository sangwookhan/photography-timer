# PTIMER-235 iteration 7 captures

Implementation commits (PR 74 head 1adfe199): d62f3639 Mini Timer 1x, a2072a02 Timers + Details (larger secondary text), 1adfe199 Main (shared label style + same text origin, seconds value fixed size). Spec baseline PR 73 revision 7dd1376b620b3bf001100f20d8cfac92edae3c0d.

Devices: Galaxy S20 SM-G981N (RFCN30XQ6YB), Android 13, 1080x2400 at 480 dpi (360 dp wide), fontScale 1.0 (restored after tests), Samsung bold text ON, 3-button bar. Emulator Pixel_10 API 37, 1080x2424 at 480 dpi. Galaxy A15 SM-A155N: NOT TESTED / PENDING (not connected during this iteration).

## Folders
- s20-before: the iteration-6 head (553b6ee7) on the S20, Korean.
- s20-after: this head on the S20, Main + Details, English and Korean, fontScale 1.0 / 1.08 / 1.2 / 1.3 / 2.0.
- emulator-before: iteration 6 (the last accepted layout), English, 1.0 / 1.3 / 2.0.
- emulator-after: this head, Main + Timers + Details, English and Korean, 1.0 / 1.2 / 1.3 / 2.0.
- measurements: uiautomator bounds; Timers/Mini Timer on the S20 were not captured per scale (the Timers sheet did not open reliably from a scripted tap; see notes).

## Changes
1. The five Main labels (Target Shutter, Base Shutter, Adjusted Shutter, Reciprocity, Corrected Exposure) now share ONE style (titleSmall 14sp) and the same left origin (8 dp card inset): Base Shutter moved from x=54 to x=72, matching the other four. They do not follow the system scale (fixed size), because Corrected Exposure + its seconds value + start button is the tightest row; 14sp is the largest size at which "Corrected Exposure" is whole next to "1540s" at every scale, in English and Korean.
2. The seconds value (339s, 1540s) is fixed too; it grew and ellipsized the Corrected Exposure label at 2.0 before.
3. Details: row labels, descriptions, Status/Source/Calculation, notes: 12sp -> 14sp. Timers: card detail lines 12sp -> 13sp (the title no longer ellipsizes on the emulator).
4. Not changed: filter management / editor texts and Mini Timer sizes (see "Not done").

## Measured results (S20, 1.0 / 1.08 / 1.2 / 1.3 / 2.0; emulator 1.0 / 1.2 / 1.3 / 2.0)
| Check | S20 en | S20 ko | Emulator en | Emulator ko |
| --- | --- | --- | --- | --- |
| Five label x origin identical to each other (72 px) | PASS all scales | PASS all scales | PASS | PASS |
| Label widths unchanged across scales | PASS (final build; the first build showed a 14 px narrowing at 1.2+, fixed by fixing the seconds value size) | PASS | PASS | PASS |
| Clickable bounds shift vs 1.0 on Main | PASS 0 px at 1.08/1.2/1.3; at 2.0 one node shifts 96 px (see note) | same | PASS 0 px | PASS 0 px |
| Details clickable shift vs 1.0 | PASS 0 px | PASS 0 px | PASS 0 px | PASS 0 px |
| Timers clickable shift vs 1.0 | not measured on S20 | not measured on S20 | PASS 0 px | PASS 0 px |
| Main shows Adjusted + Reciprocity + Corrected (value + start) with the peek, no scroll | PASS | PASS | PASS | PASS |
A15 (1.08): NOT TESTED / PENDING.

Note on the 96 px at S20 2.0: it is the Settings icon's accessibility bounds. The red DEBUG ribbon (debug builds only, drawn by the debuggable build over the top-right corner) grows with the system font and covers the icon's node; the icon, the labels, cards, wheels and result rows do not move. A release build has no ribbon. Visible in s20-after/main_*_scale-2.0.png.

## Not done / honest notes
- S20 Timers and Mini Timer per-scale matrices were not captured (tile taps did not open the sheet reliably); only the 1.0 Timers capture of the user and my emulator matrix exist. Marked NOT TESTED for the S20.
- Filter management / editor / film picker secondary text (11 to 12sp) was not enlarged in this iteration; chips remain 14sp autosize down to 9sp (no change to the 9sp floor; at the S20 the chips never reached it).
- Main labels no longer scale above 1x (fixed 14sp): the earlier SHELL-022 growth to 1.2 for labels is dropped in favour of one common size.
