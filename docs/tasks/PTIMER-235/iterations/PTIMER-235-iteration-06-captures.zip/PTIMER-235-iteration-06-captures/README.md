# PTIMER-235 iteration 06 captures

Implementation commits (PR 74 head 553b6ee7): d62f3639 Mini Timer 1x, 26110972 Timers+Details 1x (+ Details chips/values), 553b6ee7 Main. Spec baseline PR 73 revision 7dd1376b620b3bf001100f20d8cfac92edae3c0d. Same emulator (1080x2424, density 480), same state: Fomapan 100 Classic, ND 10 stops, target shutter 1m, one running timer 6m 35s unless named no-timer.

Folders: baseline-8b3b6cdb (origin/main, pre-PR), iteration5-rejected (the captures the user rejected), after (this iteration). Scales 1.0/1.2/1.3/2.0 (baseline and iteration 5: 1.0/1.3/2.0). The exact initial viewport is the screenshot itself; no scroll was used for any of them.

## Root cause
The Corrected row is hidden below the Mini Timer peek in the baseline as well: the Filter Stack header added in 0.9.0 made the page ~120 px taller than the room above the peek, and the Column gave the last children what was left. Iteration 5 tried to scroll; rejected.

## Constraint changes (no film/target/wheel/filter box touched)
1. Result card: the two dividers lose their 8 dp vertical padding (rows keep their 48 dp touch height) -> 96 px back.
2. While the peek shows: no reserved navigation-bar inset (72 px) and no gap under the page dots (24 px).
3. Model chips (Main and Details): label fitted to ONE line by shrinking the text (TextAutoSize 14sp down to 9sp) inside the chip's own height; the IntrinsicSize/fillMaxHeight growth of iteration 5 is removed; both chips are the same original 32 dp height.
4. Details: Adjusted/Corrected values share a bottom line even when a label wraps.
5. Main labels (Adjusted, Reciprocity, Corrected, seconds) grow up to 1.2 inside a 48 dp slot, no overflow. Page label 1x.
6. The page Column keeps verticalScroll only as a guard for screens too small to fit; with content that fits (all captures here) nothing scrolls.
7. Mini Timer, Timers, Details text held at 1x.

## PASS/FAIL matrix (inspected PNGs + bounds)
| Screen | 1.0 | 1.2 | 1.3 | 2.0 |
| --- | --- | --- | --- | --- |
| Main, timer peek showing: Adjusted, Reciprocity, Corrected label + primary value 6m 35s + start button visible together | PASS | PASS | PASS | PASS |
| Main model chips equal size, one line | PASS | PASS | PASS | PASS |
| Main result values aligned (34.133s / 6m 35s right edge), 395s is the secondary value | PASS | PASS | PASS | PASS |
| Main without timer | PASS | PASS | PASS | PASS |
| Main geometry vs 1.0 (clickable bounds) | - | PASS 0 px | PASS 0 px | PASS 0 px |
| Mini Timer | PASS | PASS | PASS | PASS (identical to 1.0) |
| Timers (buttons on one row, values whole) | PASS | PASS | PASS | PASS |
| Details (chips equal, values aligned) | PASS | PASS | PASS | PASS |

## Remaining / honest notes
- Compared with the baseline, the Main composition changed slightly: the result card is about 96 px shorter (divider padding) and the chips are one line. This was needed to make all three result rows visible together with the peek; it is the only way found that does not touch the film/target/wheel/filter boxes.
- Main label growth is limited to 1.2 (at 1.3 Corrected Exposure would ellipsize). Mini Timer/Timers/Details do not grow (any growth moved their components).
- Mini Timer film name ellipsized and Timers title ellipsized for long names (baseline). Below 0.85 bounds shift as in the baseline. Smaller screens than 360x808 dp will scroll the page (guard).
- Tests: ./gradlew assembleDebug test exit 0 (no layout/font tests exist).
