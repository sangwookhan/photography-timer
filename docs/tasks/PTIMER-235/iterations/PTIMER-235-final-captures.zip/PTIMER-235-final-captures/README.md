# PTIMER-235 final captures (head efb60142)

Spec baseline: PR 73 revision 7dd1376b620b3bf001100f20d8cfac92edae3c0d. Build: the final tree of PR 74 (3 commits), 0.9.0-debug.
Rule implemented: label size (the five Main labels) = clamp(14 x system fontScale, 13, 14.5) sp, rendered at the pinned 1x density; one size and one left origin for all five.

## Manifest
| Device | Locale | Scales | Screens | Folder |
| --- | --- | --- | --- | --- |
| Emulator Pixel_10, 1080x2424, 480 dpi | en, ko | 0.85, 1.0, 1.2, 1.3, 2.0 | Main (Mini Timer peek), Timers, Details | emulator/ |
| Galaxy S20 SM-G981N, 1080x2400, bold ON | en, ko | 1.0 | Main, Details | s20/ |
| Galaxy A15 SM-A155N | en, ko | 1.08 | - | NOT TESTED (phone locked; no lock-screen images are substituted) |
Names: <device>_<screen>_<locale>_scale-<fontScale>.png. measurements/ holds the uiautomator bounds; summary_geometry.txt the shift of clickable bounds vs 1.0.

## Rendered label sizes (measured widths at the same text; px)
Emulator en: Target Shutter 216 (0.85), 274 (1.0), 278 (1.2 / 1.3 / 2.0); Corrected Exposure 300, 379, 383, 383, 383. ko: Target 131, 169, 174, 174, 174. All five labels: one left origin (x = 72 px), same line-box height per scale. S20 1.0: en 278 / 250 / 327 / 219 / 385 and ko 161 / 161 / 229 / 198 / 161 (Target, Base, Adjusted, Reciprocity, Corrected), origin 72.

## Matrix (PASS = inspected PNGs and measured bounds)
| Check | Emulator en | Emulator ko | S20 1.0 en | S20 1.0 ko | A15 1.08 |
| --- | --- | --- | --- | --- | --- |
| Five labels: same size, same left origin | PASS | PASS | PASS | PASS | NOT TESTED |
| No ellipsis / clipping / overlap of the labels | PASS | PASS | PASS | PASS | NOT TESTED |
| Adjusted + Reciprocity + Corrected (value + start) with the peek, no scroll | PASS | PASS | PASS | PASS | NOT TESTED |
| Main bounds vs 1.0, scales 1.2 / 1.3 / 2.0 | 4 px (see note) | PASS 0 px | - | - | - |
| Timers bounds vs 1.0, 1.2 / 1.3 / 2.0 | PASS 0 px | PASS 0 px | not captured | not captured | NOT TESTED |
| Details bounds vs 1.0, 1.2 / 1.3 / 2.0 | PASS 0 px | PASS 0 px | no per-scale | no per-scale | NOT TESTED |
| Below default (0.85) bounds vs 1.0 | shifts 70 / 81 / 51 px (Main/Timers/Details), same cause as at baseline | 46 / 58 / 54 px | - | - | - |

Notes
- Main en 1.2/1.3/2.0 shows 4 px on the Select Filters button and the Stops/OD/ND toggle: the Base Shutter label grows from 14 to 14.5 sp between 1.0 and 1.05, which shortens the flexible gap of the header row by 4 px; no box changes size or height. Korean shows 0 px.
- 0.85: the Main page is shorter than the screen needs at that scale in the layout inherited from 0.9.0 (it is a below-default behavior that was not changed by this PR).
- S20 Timers and Mini Timer per-scale captures and the A15 round are not part of this ZIP.
