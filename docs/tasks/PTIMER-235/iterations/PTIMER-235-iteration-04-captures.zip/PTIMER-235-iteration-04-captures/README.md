# PTIMER-235 iteration 04 captures

Implementation commit: 28d4caf3 (PR 74 head; d62f3639 Mini Timer 1x, d24d6de4 Timers+Details 1x, 28d4caf3 Main labels in fixed slots, amended from 40167a34). Spec baseline PR 73 revision 7dd1376b620b3bf001100f20d8cfac92edae3c0d.
Before = origin/main 8b3b6cdb. After = 28d4caf3. Same emulator (1080x2424, density 480 = 360 dp wide, Roboto font), same state: Fomapan 100 Classic, ND 10 stops, target shutter 1m, one running timer 6m 35s unless named no-timer.

## Files
before/ and after/: main, timers, details at scale 1.0, 1.3, 2.0 (after also main_scale-1.2); main-no-timer_* (Corrected Exposure row visible) at 1.0/2.0 before and 1.0/1.2/2.0 after.
measurements/: uiautomator bounds per file; summary_geometry.txt (clickable bounds shift vs 1.0); verdict_*.txt (per text node vs 1.0: position shift, height ratio = line count, left edge); label_slot_and_neighbours.txt.

## PASS/FAIL (after, at 1.2 and 2.0 vs 1.0, identical state)
| Screen | Geometry | Line count | Alignment | Readability |
| --- | --- | --- | --- | --- |
| Main (no timer) | PASS 0 px all 17 components | PASS every one-line label stays one line | PASS label/value centres identical, Adjusted and Corrected values on the row centre | PASS no ellipsis, no overlap (59 px gap Corrected->395s) |
| Main (timer) | PASS 0 px | PASS | PASS (the 2 px reading on Corrected Exposure/395s is the accessibility bounds clipped by the timer peek bar; the no-timer run shows 0 px) | PASS |
| Mini Timer | PASS identical to 1.0 | PASS | PASS | PASS countdown whole; film name ellipsis exists at 1.0 too |
| Timers | PASS 0 px | PASS | PASS | PASS (text held at 1x) |
| Details | PASS 0 px | PASS "Corrected Exposure" and "Adjusted Shutter" one line | PASS both values on one line, same top | PASS (text held at 1x) |
Label scale on Main is capped at 1.2: at 1.3 the Corrected Exposure label ellipsizes next to the seconds value.

## Reported failures that do not reproduce here
- "App-derived formula" on Main wraps to two lines at 1.0 on this emulator already, and is identical (same bounds) at every scale before and after; Main is pinned at 1x. A one-line baseline on the user's device suggests a narrower system font there (SM-G981N, same 360 dp width); font cannot be reproduced on the emulator.
- Details "Corrected Exposure" wrapping: not present in this head (Details is held at 1x). It occurs in 0.9.0 at 1.3 and in the earlier iteration-1 build at 1.7 (Adjusted/Shutter wrap). Which build was tested is unknown.

## Remaining defects
- Corrected Exposure row hidden by the timer peek bar on Main (baseline).
- Mini Timer film name ellipsized, title in Timers ellipsized for long names (baseline).
- Below default (0.85) bounds shift as in the baseline.
