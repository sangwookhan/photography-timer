# PTIMER-235 iteration 9: Main label size comparison (evaluation only)

The code on the branch is unchanged (head 04627e3a at 14.5 sp). Trial builds with the shared label size 13, 13.5, 14, 14.5 sp were made locally and never committed. Same Main content in each pair; geometry identical (the label size does not change any box). compare.html puts the four sizes side by side per device and language.

Devices: S20 SM-G981N fontScale 1.0 (bold text ON); A15 SM-A155N fontScale 1.08; emulator 1.0. Languages en and ko.

## Measured fit (px; the widths are the text node width)
S20 en: Target Shutter 258/267/278/286 px, gap to the stop arrow 38/29/18/10 px; Corrected Exposure 355/366/385/387 px, gap to the seconds value 71/60/41/39 px (13 / 13.5 / 14 / 14.5 sp).
S20 ko: Target 153/157/161/166 px, gaps 176/172/168/163; Corrected 153/157/161/166.
A15 en: Target 234/241/256/258 px, gap to arrow 108/101/86/84; Corrected 323/332/351/357.
A15 ko: Target 136/140/149/149, gap 236/232/223/223.
Emulator en: Target 256/258/274/278, gap 67/65/49/45; Corrected gap to seconds 129/122/101/97.
Raw bounds in measurements/.
