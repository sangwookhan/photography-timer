# PTIMER-235 iteration 7: Galaxy A15 device acceptance (head 1adfe199)

Device: Galaxy A15 SM-A155N (RF9XA004RKP), Android 16, 1080x2340, 450 dpi, fontScale 1.08 (everyday), gesture navigation, locale ko-KR (tested ko and en via per-app language), 4 camera slots with history.
Tested scales: 1.0, 1.08, 1.2, 1.3, 2.0; screens Main (with Mini Timer), Details, Timers; ko + en. Everyday fontScale restored to 1.08, per-app language set back to ko-KR.

## Results
| Check | en | ko |
| --- | --- | --- |
| Five labels: same size, same left origin (x=68 px) at 1.0 / 1.08 / 2.0 | PASS | PASS |
| Main: Adjusted + Reciprocity + Corrected (value + start) with the peek, no scroll | PASS | PASS |
| Main bounds vs 1.0 at 1.08 / 1.2 / 1.3 | PASS 0 px | PASS 0 px |
| Main bounds vs 1.0 at 2.0 | 10 px (Settings icon bounds, see note) | 10 px |
| Details bounds vs 1.0 (1.08 to 2.0) | PASS 0 px | PASS 0 px |
| Timers bounds vs 1.0 (1.08 to 2.0) | PASS 0 px | PASS 0 px |
| Model chips equal height, one line | PASS | PASS |
Note: the 10 px at 2.0 is the Settings icon's accessibility bounds covered by the debug build's red DEBUG ribbon, which grows with the system font (see main_ko_scale-2.0.png). It is not an app layout shift.

## Existing issue seen on this device (also at baseline)
The Timers full-screen sheet draws its close icon and title under the status bar (close X over the clock). Baseline 8b3b6cdb shows the same (timers_en_baseline-8b3b6cdb_scale-1.0.png). Not changed by this PR; reported only.

## First attempt note
The first run captured black screens because the device screen timed out; the matrix was rerun with stay-awake enabled and the results above come from the rerun.
