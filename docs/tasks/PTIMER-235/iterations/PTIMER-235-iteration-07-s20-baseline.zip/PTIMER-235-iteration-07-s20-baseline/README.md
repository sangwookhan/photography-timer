# PTIMER-235 iteration 7: S20 baseline (head 553b6ee7, before any iteration-7 change)

Device: Galaxy S20 SM-G981N, Android 13, physical 1440x3200, use size 1080x2400, density 480 (360 dp wide), fontScale 1.0, Samsung "bold text" ON (font_weight_adjustment 300), font style "default", 3-button navigation bar, Korean UI. App 0.9.0-debug (head 553b6ee7).
Content: Camera 2, Kentmere 100, three ND wheels + auxiliary filter column, one running timer + history tiles.

Files: s20-baseline/main_1.0, details_1.0, filters_1.0; timers and filter-editor are user-supplied captures of the same device (the Timers tile did not open from my tap). measurements/ = uiautomator bounds.
