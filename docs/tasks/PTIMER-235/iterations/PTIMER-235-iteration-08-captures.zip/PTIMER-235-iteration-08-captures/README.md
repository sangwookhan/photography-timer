# PTIMER-235 iteration 8 captures: Main label size

Head: see PR #74 (the Main commit amended). Spec baseline PR 73 revision 7dd1376b620b3bf001100f20d8cfac92edae3c0d.
Change: the five Main labels (Target Shutter, Base Shutter, Adjusted Shutter, Reciprocity, Corrected Exposure) go from 14 sp to 14.5 sp, one common size and the same left origin; nothing else changed.

## Size trials (selected = 14.5 sp)
| Size | S20 en | S20 ko | A15 en | A15 ko | Emulator en |
| --- | --- | --- | --- | --- | --- |
| 15 sp | FAIL: "Corrected Exposu..." ellipsized beside the seconds value; Target Shutter touches the arrow | fits | fits (gap 68 px to the arrow) | fits | fits |
| 16 sp | FAIL: "Target Shut..." and "Corrected Expos..." ellipsized; header Select Filters/Stops row squeezed | fits | fits, tight | fits | FAIL: Target Shutter touches the arrow; header squeezed |
| 14.5 sp | PASS: Corrected Exposure whole, Target Shutter whole | PASS | PASS | PASS | PASS |
Constraint: the S20 (360 dp, bold text ON) English "Corrected Exposure" row. Its label has to share the line with the seconds value (about 24 px gap at 14.5 sp) and the start button; at 15 sp it needs about 8 px more than is allotted and would ellipsize, which the instruction does not allow. Geometry was not changed to make room. 14.5 sp is the largest common size that is whole on every device in both languages. (Target Shutter English at 14.5 sp still leaves only a few px before the stop-difference arrow on the S20.)

## Matrix at 14.5 sp
| Check | S20 1.0 en | S20 1.0 ko | A15 1.08 en | A15 1.08 ko | Emulator en 1.0/1.2/1.3/2.0 | Emulator ko 1.0/1.2/1.3/2.0 |
| --- | --- | --- | --- | --- | --- | --- |
| Five labels same size and same left origin | PASS | PASS | PASS | PASS | PASS | PASS |
| No ellipsis or clipping of the five labels | PASS | PASS | PASS | PASS | PASS | PASS |
| Adjusted + Reciprocity + Corrected (value + start) with the peek, no scroll | PASS | PASS | PASS | PASS | PASS | PASS |
| Clickable bounds shift vs 1.0 (Main, Details, Timers) | not run | not run | not run | not run | PASS 0 px | PASS 0 px |
Folders: before-14sp (iteration 7 head), after-14.5sp, size-trials (15/16 sp captures that fail or are tight), measurements.
Not tested: S20 and A15 at other scales and Details/Timers (not part of this typography-only change).
