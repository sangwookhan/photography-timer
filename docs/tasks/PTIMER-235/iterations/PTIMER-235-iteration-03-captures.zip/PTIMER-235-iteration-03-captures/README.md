# PTIMER-235 iteration 03 captures

Implementation commit: 40167a34 (PR 74 head; d62f3639 Mini Timer 1x, d24d6de4 Timers+Details 1x, 40167a34 Main labels in fixed slots). Spec baseline PR 73 revision 7dd1376b620b3bf001100f20d8cfac92edae3c0d.
Before = origin/main 8b3b6cdb. After = 40167a34. Same emulator (1080x2424, density 480, en-US), same state: Fomapan 100 Classic, ND 10 stops, target shutter 1m, one running timer 6m 35s.

## Files
| Screen | before | after |
| --- | --- | --- |
| Main + Mini Timer, scales 1.0 / 1.3 / 2.0 | before/main_scale-*.png | after/main_scale-*.png |
| Timers | before/timers_scale-*.png | after/timers_scale-*.png |
| Details | before/details_scale-*.png | after/details_scale-*.png |
| Main without a timer (Corrected Exposure row visible), 1.0 / 1.2 / 2.0 | - | after/main-no-timer_scale-*.png |

measurements/: uiautomator bounds per screen and scale; summary.txt = max shift of clickable bounds vs 1.0 (0 px everywhere above 1.0).

## Root cause and change
A result label's own height took part in its row's measurement (the label is the only child whose height tracks the font), so a bigger label moved the rows below (2 px at 1.05, 11 px at 1.15 before the fix). Fix: each enlarging label is wrapped in a slot as tall as the label is at 1x, with the text centred and allowed to overflow it vertically, and the result label takes the remaining row width. Labels: Adjusted Shutter, Corrected Exposure, Reciprocity, seconds value, page position. Cap 1.2: at 1.3 "Corrected Exposure" ellipsizes next to the seconds value (measured), at 1.2 it is whole.
Structure before: Row { Text(label); Spacer(weight 1); value; button } with the label sizing the row. After: Row { Box(label slot, fixed 1x height, weight 1) { Text }; value; button }.

## Remaining visual defects
- Main at max system scale: labels are scaled to 1.2 only (cap), so they do not grow further.
- Corrected Exposure row hidden by the timer peek bar on Main with a timer (baseline issue, unchanged).
- Mini Timer film name ellipsized; Mini Timer, Timers, Details held at 1x (text does not grow).
- Below default (0.85) bounds shift as in the baseline (not changed).
- The "1 of 4" page label overlaps nothing at 1.2 but is vertically centred in its 1x slot.
